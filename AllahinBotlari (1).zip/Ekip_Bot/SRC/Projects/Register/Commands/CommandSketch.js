const { Discord, MessageEmbed } = require("discord.js");
module.exports.execute = async(RegisterClient , message, args) => {
    message.channel.send("sa")  
};

module.exports.registerconfig = {
    name: "taslak3",
    aliases: [],
    usage: "Taslak",
    description: "Taslak Komutu."
};