const {MessageEmbed, Discord, Guild} = require('discord.js');

class RegisterSetup {
    static regOnline() {
        RegisterClient.login(conf.register)
}

}
module.exports = RegisterSetup;
