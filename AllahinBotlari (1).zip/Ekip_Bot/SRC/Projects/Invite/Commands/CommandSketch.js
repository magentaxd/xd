const { Discord, MessageEmbed } = require("discord.js");
module.exports.execute = async(InviteClient , message, args) => {
    message.channel.send("sa")  
};

module.exports.inviteconfig = {
    name: "taslak5",
    aliases: [],
    usage: "Taslak",
    description: "Taslak Komutu."
};