const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard4Setup {
    static grd4Online() {
        Guard4Client.login(conf.guard4)
}

}
module.exports = Guard4Setup;
