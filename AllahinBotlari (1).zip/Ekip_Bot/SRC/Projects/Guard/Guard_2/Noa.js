const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard2Setup {
    static grd2Online() {
        Guard2Client.login(conf.guard2)
}

}
module.exports = Guard2Setup;
