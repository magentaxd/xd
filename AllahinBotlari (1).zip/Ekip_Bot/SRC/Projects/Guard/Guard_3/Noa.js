const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard3Setup {
    static grd3Online() {
        Guard3Client.login(conf.guard3)
}

}
module.exports = Guard3Setup;
