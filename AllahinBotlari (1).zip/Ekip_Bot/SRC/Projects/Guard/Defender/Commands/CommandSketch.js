const { Discord, MessageEmbed } = require("discord.js");
module.exports.execute = async(DefenderClient , message, args) => {
    message.channel.send("sa ulan")  
};

module.exports.defenderconfig = {
    name: "italy",
    aliases: [],
    usage: "Taslak",
    description: "Taslak Komutu."
};