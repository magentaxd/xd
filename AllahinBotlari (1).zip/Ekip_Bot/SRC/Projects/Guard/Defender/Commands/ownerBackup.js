const { Discord, MessageEmbed } = require("discord.js");
module.exports.execute = async(DefenderClient , message, args) => {
    message.channel.send("sa ulan")  
};

module.exports.defenderconfig = {
    name: "xrd",
    aliases: [],
    usage: "Taslak",
    description: "Taslak Komutu."
};