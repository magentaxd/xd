const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard3Setup {
    static grd3Online() {
        DefenderClient.login(conf.defender)
}
}
module.exports = Guard3Setup;
