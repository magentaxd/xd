const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard5Setup {
    static grd5Online() {
        Guard5Client.login(conf.guard5)
}

}
module.exports = Guard5Setup;
