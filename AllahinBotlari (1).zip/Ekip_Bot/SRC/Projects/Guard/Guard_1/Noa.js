const {MessageEmbed, Discord, Guild} = require('discord.js');

class Guard1Setup {
    static grd1Online() {
        Guard1Client.login(conf.guard1)
}

}
module.exports = Guard1Setup;
