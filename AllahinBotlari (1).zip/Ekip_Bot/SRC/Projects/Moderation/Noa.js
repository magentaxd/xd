const {MessageEmbed, Discord, Guild} = require('discord.js');

class ModerationSetup {
    static modOnline() {
            ModerationClient.login(conf.moderation)
}

}
module.exports = ModerationSetup;
