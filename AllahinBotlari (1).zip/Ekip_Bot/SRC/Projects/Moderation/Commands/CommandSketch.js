const { Discord, MessageEmbed } = require("discord.js");
module.exports.execute = async(ModerationClient , message, args) => {
    message.channel.send("sa")  
};

module.exports.config = {
    name: "taslak2",
    aliases: [],
    usage: "Taslak",
    description: "Taslak Komutu."
};